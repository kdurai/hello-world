package com.citi.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.citi.model.Message;

public class MessageBoardServiceImpl implements MessageBoardService {

	private Map<Long,Message> messages = new LinkedHashMap<Long,Message>();
	
	@Override
	public List<Message> listMessages() {
		// TODO Auto-generated method stub
		return new ArrayList<Message>(messages.values());
	}

	@Override
	public synchronized void postMessage(Message message) {
		// TODO Auto-generated method stub
		message.setId(System.currentTimeMillis());
		messages.put(message.getId(),message);
	}

	@Override
	public synchronized void deleteMessage(Message message) {
		// TODO Auto-generated method stub
		messages.remove(message.getId());
	}

	@Override
	public Message findMessageById(Long messageId) {
		// TODO Auto-generated method stub
		return messages.get(messageId);
	}

}
